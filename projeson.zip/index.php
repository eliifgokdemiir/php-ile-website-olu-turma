<style>
body{
    border: 2px solid black;
    padding: 25px;
    background-size: cover;
            
}

input{
	background-color: transparent;
	border: none;
	border-bottom: 1px solid black;
	border-radius: 5px;
}
select{
	background-color: transparent;
	border: none;
	border-bottom: 1px ;
}
input::placeholder{
	color: #000000;
}
.button {
    background-color: #4CAF50; 
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}
.button1{
	background-color: #4CAF50;
	border-radius: 4px;
}
.button1:hover {
    background-color: transparent;
    color: white;
    border: 2px solid #4CAF50;
}
.saga{
float:right;
padding:0 50px 0px;
color: #ffcc00;
font-style: bold;
font-size: 20px;
}

nav{
  float: left;
}
</style>

<html>
<head>
<title>HOTEL ELİZA</title>
<link rel="shortcut icon" href="el.png">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<div class="w3-top">
  <nav class="w3-bar w3-black">
    <a href="index.php" class="w3-button w3-bar-item"><img src="el.png" width="25" height="25"> HOTEL ELİZA</a>
    <a href="aboutc.php" class="w3-button w3-bar-item">HAKKIMIZDA</a>
    <a href="admin/login.php" class="w3-button w3-bar-item">GİRİŞ</a>
    <a href="odalar.php" class="w3-button w3-bar-item">ODALAR</a>
    <a href="foto.php" class="w3-button w3-bar-item">FOTOĞRAFLAR</a>
    <a href="bizeulas.php" class="w3-button w3-bar-item">BİZE ULAŞIN</a>
    <a href="form.php"  class="saga">REZERVASYON</a>
  </nav>
</div>
</head>
<body background="mann.jpg" align="center">

	<form method="post" action="dosignup.php" >
<!-- Navigation -->

<br><br>
<!-- Band Description -->

  <section class="w3-container w3-center w3-content" style="max-width:600px">
  
	
  <img src="el.png" width="200" height="200"><br>
 <br>
  <h2 class="w3-opacity"><i><b>Lüks, Konfor ve Türk</i></b></i></h2>
  	<h4 class="w3-opacity"><b><i>Misafirperverliği</i></h5>

</section>
	</form>
</body>
</html>





	
