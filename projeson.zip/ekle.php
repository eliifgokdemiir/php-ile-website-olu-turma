<!DOCTYPE html>
<html>
<body>
<?php 

$con = mysqli_connect("localhost","root","","rezervasyon") or die(mysql_error());


//header("Location: /web364ayşesu/proje/ekle.php");
//echo "lütfen bekleyiniz";
?>
</body>
</html>